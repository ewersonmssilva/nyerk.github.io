<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Nyerk - Search</title>



<!--
	phpBB style name: we_universal
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:      nextgen ( http://xeronix.org/ )
-->


<link href="./styles/prosilver/theme/stylesheet.css?assets_version=25" rel="stylesheet">
<link href="./assets/css/font-awesome.min.css?assets_version=25" rel="stylesheet">
<link href="./styles/we_universal/theme/stylesheet.css?assets_version=25" rel="stylesheet">
<link href="./styles/prosilver/theme/responsive.css?assets_version=25" rel="stylesheet">
<link href="./styles/we_universal/theme/responsive.css?assets_version=25" rel="stylesheet">




<!--[if lte IE 9]>
	<link href="./styles/prosilver/theme/tweaks.css?assets_version=25" rel="stylesheet">
<![endif]-->


<link href="./ext/gfksx/ThanksForPosts/styles/prosilver/theme/thanks.css?assets_version=25" rel="stylesheet" type="text/css" media="screen" />



<!--[if lt IE 9]>
	<script type="text/javascript" src="./styles/we_universal/template/html5shiv.min.js"></script>
<![endif]-->

</head>
<body id="phpbb" class="nojs notouch section-search ltr  logged-out">


<div id="wrap" class="wrap">
	<a id="top" class="top-anchor" accesskey="t"></a>

	<div class="inventea-headerbar">
		<nav class="inventea-wrapper inventea-userbar">
			<div class="dropdown-container hidden inventea-mobile-dropdown-menu">
    <a href="#" class="dropdown-trigger inventea-toggle"><i class="icon fa fa-bars"></i></a>
    <div class="dropdown hidden">
        <div class="pointer"><div class="pointer-inner"></div></div>
        <ul class="dropdown-contents" role="menubar">
		
														
							<li>
								<a href="./index.php" role="menuitem">
									<i class="icon fa fa-fw fa-home" aria-hidden="true"></i><span>Board index</span>
								</a>
							</li>		
							
							<li data-skip-responsive="true">
								<a href="/app.php/help/faq" rel="help" title="Frequently Asked Questions" role="menuitem">
									<i class="icon fa-question-circle fa-fw" aria-hidden="true"></i><span>FAQ</span>
								</a>
							</li>
							
													<li>
								<a href="./search.php" role="menuitem">
									<i class="icon fa-search fa-fw" aria-hidden="true"></i><span>Search</span>
								</a>
							</li>
							
														
														
								
						
							<li>
								<a href="./search.php?search_id=unanswered" role="menuitem">
									<i class="icon fa-file-o fa-fw icon-gray" aria-hidden="true"></i><span>Unanswered topics</span>
								</a>
							</li>
							<li>
								<a href="./search.php?search_id=active_topics" role="menuitem">
									<i class="icon fa-file-o fa-fw icon-blue" aria-hidden="true"></i><span>Active topics</span>
								</a>
							</li>
							<li class="separator"></li>
	
						
							
            																			<li>
								<a href="./memberlist.php?mode=team" role="menuitem">
									<i class="icon fa-shield fa-fw" aria-hidden="true"></i><span>The team</span>
								</a>
							</li>
						            
				                    </ul>
    </div>
</div>

			
			<ul class="linklist bulletin inventea-user-menu" role="menubar">
										<li class="small-icon rightside" data-skip-responsive="true"><a href="./ucp.php?mode=login" title="Login" accesskey="x" role="menuitem"><i class="icon fa-fw fa-sign-in" aria-hidden="true"></i>Login</a></li>
											<li class="small-icon rightside" data-skip-responsive="true"><a href="./ucp.php?mode=register" role="menuitem"><i class="icon fa-fw fa-user-plus" aria-hidden="true"></i>Register</a></li>
										
										
							</ul>
		</nav>
	</div>

	<header class="inventea-header">
			
		<div class="inventea-dashboard" role="banner">
						<nav role="navigation">
	<div class="inventea-posts-menu">
		<ul class="inventea-menu" role="menubar">
			
																			<li><a href="./search.php?search_id=unanswered" role="menuitem">Unanswered topics</a></li>
				<li><a href="./search.php?search_id=active_topics" role="menuitem">Active topics</a></li>
			
					</ul>
	</div>

	<div class="inventea-forum-menu">
		<ul class="inventea-menu" role="menubar">
			
			<li><a href="/app.php/help/faq" rel="help" title="Frequently Asked Questions" role="menuitem">FAQ</a></li>
			<li><a href="./search.php" role="menuitem">Search</a></li>
											<li><a href="./memberlist.php?mode=team" role="menuitem">The team</a></li>			
						
					</ul>
	</div>
</nav>

			<div class="inventea-sitename">
				<h1><a href="./index.php" title="Board index">Nyerk</a></h1>
				<span>An Forum about Aion</span>
			</div>
		</div>
			</header>

	<div class="inventea-wrapper inventea-content" role="main">
		
		<ul id="nav-breadcrumbs" class="linklist navlinks" role="menubar">
			
									<li class="small-icon breadcrumbs">
												<span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="./index.php" accesskey="h" data-navbar-reference="index" itemprop="url"><span itemprop="title">Board index</span></a></span>
											</li>
					</ul>

		
		
<h2 class="solo">Search</h2>

<form method="get" action="./search.php" data-focus="keywords">

<div class="panel">
	<div class="inner">
	<h3>Search query</h3>

		<fieldset>
		<dl>
		<dt><label for="keywords">Search for keywords:</label><br /><span>Place <strong>+</strong> in front of a word which must be found and <strong>-</strong> in front of a word which must not be found. Put a list of words separated by <strong>|</strong> into brackets if only one of the words must be found. Use * as a wildcard for partial matches.</span></dt>
		<dd><input type="search" class="inputbox" name="keywords" id="keywords" size="40" title="Search for keywords" /></dd>
		<dd><label for="terms1"><input type="radio" name="terms" id="terms1" value="all" checked="checked" /> Search for all terms or use query as entered</label></dd>
		<dd><label for="terms2"><input type="radio" name="terms" id="terms2" value="any" /> Search for any terms</label></dd>
	</dl>
	<dl>
		<dt><label for="author">Search for author:</label><br /><span>Use * as a wildcard for partial matches.</span></dt>
		<dd><input type="search" class="inputbox" name="author" id="author" size="40" title="Search for author" /></dd>
	</dl>
		</fieldset>
	
	</div>
</div>

<div class="panel bg2">
	<div class="inner">

	<h3>Search options</h3>

		<fieldset>
		<dl>
		<dt><label for="search_forum">Search in forums:</label><br /><span>Select the forum or forums you wish to search in. Subforums are searched automatically if you do not disable “search subforums“ below.</span></dt>
		<dd><select name="fid[]" id="search_forum" multiple="multiple" size="8" title="Search in forums"><option value="3">AionScript</option><option value="2">&nbsp; &nbsp;Announcements</option><option value="6">&nbsp; &nbsp;General Discussion</option><option value="7">&nbsp; &nbsp;Tutorials</option><option value="4">&nbsp; &nbsp;Downloads</option><option value="8">&nbsp; &nbsp;LUA Scripting</option><option value="9">&nbsp; &nbsp;&nbsp; &nbsp;Assassin</option><option value="10">&nbsp; &nbsp;&nbsp; &nbsp;Bard</option><option value="11">&nbsp; &nbsp;&nbsp; &nbsp;Gladiator</option><option value="12">&nbsp; &nbsp;&nbsp; &nbsp;Templar</option><option value="13">&nbsp; &nbsp;&nbsp; &nbsp;Ranger</option><option value="14">&nbsp; &nbsp;&nbsp; &nbsp;Spiritmaster</option><option value="15">&nbsp; &nbsp;&nbsp; &nbsp;Sorcerer</option><option value="16">&nbsp; &nbsp;&nbsp; &nbsp;Cleric</option><option value="17">&nbsp; &nbsp;&nbsp; &nbsp;Chanter</option><option value="18">&nbsp; &nbsp;&nbsp; &nbsp;Gunner</option><option value="19">&nbsp; &nbsp;&nbsp; &nbsp;Aethertech</option></select></dd>
	</dl>
	<dl>
		<dt><label for="search_child1">Search subforums:</label></dt>
		<dd>
			<label for="search_child1"><input type="radio" name="sc" id="search_child1" value="1" checked="checked" /> Yes</label>
			<label for="search_child2"><input type="radio" name="sc" id="search_child2" value="0" /> No</label>
		</dd>
	</dl>
	<dl>
		<dt><label for="sf1">Search within:</label></dt>
		<dd><label for="sf1"><input type="radio" name="sf" id="sf1" value="all" checked="checked" /> Post subjects and message text</label></dd>
		<dd><label for="sf2"><input type="radio" name="sf" id="sf2" value="msgonly" /> Message text only</label></dd>
		<dd><label for="sf3"><input type="radio" name="sf" id="sf3" value="titleonly" /> Topic titles only</label></dd>
		<dd><label for="sf4"><input type="radio" name="sf" id="sf4" value="firstpost" /> First post of topics only</label></dd>
	</dl>
	
	<hr class="dashed" />

		<dl>
		<dt><label for="show_results1">Display results as:</label></dt>
		<dd>
			<label for="show_results1"><input type="radio" name="sr" id="show_results1" value="posts" checked="checked" /> Posts</label>
			<label for="show_results2"><input type="radio" name="sr" id="show_results2" value="topics" /> Topics</label>
		</dd>
	</dl>
	<dl>
		<dt><label for="sd">Sort results by:</label></dt>
		<dd><select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="f">Forum</option><option value="i">Topic title</option><option value="s">Post subject</option></select>&nbsp;
			<label for="sa"><input type="radio" name="sd" id="sa" value="a" /> Ascending</label>
			<label for="sd"><input type="radio" name="sd" id="sd" value="d" checked="checked" /> Descending</label>
		</dd>
	</dl>
	<dl>
		<dt><label>Limit results to previous:</label></dt>
		<dd><select name="st" id="st"><option value="0" selected="selected">All results</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></dd>
	</dl>
	<dl>
		<dt><label>Return first:</label></dt>
		<dd><select name="ch" title="Return first"><option value="-1">All available</option><option value="0">0</option><option value="25">25</option><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="300" selected="selected">300</option><option value="400">400</option><option value="500">500</option><option value="600">600</option><option value="700">700</option><option value="800">800</option><option value="900">900</option><option value="1000">1000</option></select> characters of posts</dd>
	</dl>
		</fieldset>
	
	</div>
</div>

<div class="panel bg3">
	<div class="inner">

	<fieldset class="submit-buttons">
		<input type="hidden" name="t" value="0" />
<input type="reset" value="Reset" name="reset" class="button2" />&nbsp;
		<input type="submit" name="submit" value="Search" class="button1" />
	</fieldset>

	</div>
</div>

</form>


				
			</div>

	<div class="inventea-footer-wrapper">
		<div id="page-footer" class="inventea-footer" role="contentinfo">
			<nav role="navigation">
	<ul id="nav-footer" class="nav-footer linklist" role="menubar">
		<li class="breadcrumbs">
									<span class="crumb"><a href="./index.php" data-navbar-reference="index"><span>Board index</span></a></span>					</li>

						<li class="small-icon" data-last-responsive="true"><a href="./memberlist.php?mode=contactadmin" role="menuitem">Contact us</a></li>
				
		<li class="small-icon"><a href="./ucp.php?mode=delete_cookies" data-ajax="true" data-refresh="true" role="menuitem">Delete all board cookies</a></li>
				<li>All times are <span title="UTC">UTC</span></li>
			</ul>
</nav>

			<footer class="inventea-credits">
								Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Limited<br />
								Style we_universal created by <a href="https://inventea.com/" title="phpBB styles, HTML5 &amp; CSS3 templates">INVENTEA</a> & <a href="http://xeronix.org/" title="phpBB styles and much more">nextgen</a>
											</footer>
		</div>
	</div>

	<div id="darkenwrapper" class="darkenwrapper" data-ajax-error-title="AJAX error" data-ajax-error-text="Something went wrong when processing your request." data-ajax-error-text-abort="User aborted request." data-ajax-error-text-timeout="Your request timed out; please try again." data-ajax-error-text-parsererror="Something went wrong with the request and the server returned an invalid reply.">
		<div id="darken" class="darken">&nbsp;</div>
	</div>

	<div id="phpbb_alert" class="phpbb_alert" data-l-err="Error" data-l-timeout-processing-req="Request timed out.">
		<a href="#" class="alert_close">
			<i class="icon fa-times-circle fa-fw" aria-hidden="true"></i>
		</a>
	<h3 class="alert_title">&nbsp;</h3><p class="alert_text"></p>
	</div>
	<div id="phpbb_confirm" class="phpbb_alert">
		<a href="#" class="alert_close">
			<i class="icon fa-times-circle fa-fw" aria-hidden="true"></i>
		</a>
		<div class="alert_text"></div>
	</div>

<div>
	<a id="bottom" class="anchor" accesskey="z"></a>
	</div>
</div>

<script type="text/javascript" src="./assets/javascript/jquery.min.js?assets_version=25"></script>
<script type="text/javascript" src="./assets/javascript/core.js?assets_version=25"></script>



<script type="text/javascript" src="./styles/prosilver/template/forum_fn.js?assets_version=25"></script>
<script type="text/javascript" src="./styles/prosilver/template/ajax.js?assets_version=25"></script>



</body>
</html>
