<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<title>Nyerk - Index page</title>



<!--
	phpBB style name: we_universal
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:      nextgen ( http://xeronix.org/ )
-->


<link href="./styles/prosilver/theme/stylesheet.css?assets_version=25" rel="stylesheet">
<link href="./assets/css/font-awesome.min.css?assets_version=25" rel="stylesheet">
<link href="./styles/we_universal/theme/stylesheet.css?assets_version=25" rel="stylesheet">
<link href="./styles/prosilver/theme/responsive.css?assets_version=25" rel="stylesheet">
<link href="./styles/we_universal/theme/responsive.css?assets_version=25" rel="stylesheet">




<!--[if lte IE 9]>
	<link href="./styles/prosilver/theme/tweaks.css?assets_version=25" rel="stylesheet">
<![endif]-->


<link href="./ext/gfksx/ThanksForPosts/styles/prosilver/theme/thanks.css?assets_version=25" rel="stylesheet" type="text/css" media="screen" />



<!--[if lt IE 9]>
	<script type="text/javascript" src="./styles/we_universal/template/html5shiv.min.js"></script>
<![endif]-->

</head>
<body id="phpbb" class="nojs notouch section-index ltr  logged-out">


<div id="wrap" class="wrap">
	<a id="top" class="top-anchor" accesskey="t"></a>

	<div class="inventea-headerbar">
		<nav class="inventea-wrapper inventea-userbar">
			<div class="dropdown-container hidden inventea-mobile-dropdown-menu">
    <a href="#" class="dropdown-trigger inventea-toggle"><i class="icon fa fa-bars"></i></a>
    <div class="dropdown hidden">
        <div class="pointer"><div class="pointer-inner"></div></div>
        <ul class="dropdown-contents" role="menubar">
		
														
							<li>
								<a href="./index.php" role="menuitem">
									<i class="icon fa fa-fw fa-home" aria-hidden="true"></i><span>Board index</span>
								</a>
							</li>		
							
							<li data-skip-responsive="true">
								<a href="/app.php/help/faq" rel="help" title="Frequently Asked Questions" role="menuitem">
									<i class="icon fa-question-circle fa-fw" aria-hidden="true"></i><span>FAQ</span>
								</a>
							</li>
							
													<li>
								<a href="./search.php" role="menuitem">
									<i class="icon fa-search fa-fw" aria-hidden="true"></i><span>Search</span>
								</a>
							</li>
							
														
														
								
						
							<li>
								<a href="./search.php?search_id=unanswered" role="menuitem">
									<i class="icon fa-file-o fa-fw icon-gray" aria-hidden="true"></i><span>Unanswered topics</span>
								</a>
							</li>
							<li>
								<a href="./search.php?search_id=active_topics" role="menuitem">
									<i class="icon fa-file-o fa-fw icon-blue" aria-hidden="true"></i><span>Active topics</span>
								</a>
							</li>
							<li class="separator"></li>
	
						
							
            																			<li>
								<a href="./memberlist.php?mode=team" role="menuitem">
									<i class="icon fa-shield fa-fw" aria-hidden="true"></i><span>The team</span>
								</a>
							</li>
						            
				                    </ul>
    </div>
</div>

			
			<ul class="linklist bulletin inventea-user-menu" role="menubar">
										<li class="small-icon rightside" data-skip-responsive="true"><a href="./ucp.php?mode=login" title="Login" accesskey="x" role="menuitem"><i class="icon fa-fw fa-sign-in" aria-hidden="true"></i>Login</a></li>
											<li class="small-icon rightside" data-skip-responsive="true"><a href="./ucp.php?mode=register" role="menuitem"><i class="icon fa-fw fa-user-plus" aria-hidden="true"></i>Register</a></li>
										
										
							</ul>
		</nav>
	</div>

	<header class="inventea-header">
			
		<div class="inventea-dashboard" role="banner">
						<nav role="navigation">
	<div class="inventea-posts-menu">
		<ul class="inventea-menu" role="menubar">
			
																			<li><a href="./search.php?search_id=unanswered" role="menuitem">Unanswered topics</a></li>
				<li><a href="./search.php?search_id=active_topics" role="menuitem">Active topics</a></li>
			
					</ul>
	</div>

	<div class="inventea-forum-menu">
		<ul class="inventea-menu" role="menubar">
			
			<li><a href="/app.php/help/faq" rel="help" title="Frequently Asked Questions" role="menuitem">FAQ</a></li>
			<li><a href="./search.php" role="menuitem">Search</a></li>
											<li><a href="./memberlist.php?mode=team" role="menuitem">The team</a></li>			
						
					</ul>
	</div>
</nav>

			<div class="inventea-sitename">
				<h1><a href="./index.php" title="Board index">Nyerk</a></h1>
				<span>An Forum about Aion</span>
			</div>
		</div>
			</header>

	<div class="inventea-wrapper inventea-content" role="main">
		
		<ul id="nav-breadcrumbs" class="linklist navlinks" role="menubar">
							<li class="rightside inventea-time">It is currently Sat May 12, 2018 9:11 am</li>
			
									<li class="small-icon breadcrumbs">
												<span class="crumb" itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="./index.php" accesskey="h" data-navbar-reference="index" itemprop="url"><span itemprop="title">Board index</span></a></span>
											</li>
					</ul>

		
		
<p class="right responsive-center time">It is currently Sat May 12, 2018 9:11 am</p>



	
				<div class="forabg">
			<div class="inner">
			<ul class="topiclist">
				<li class="header">
										<dl class="row-item">
						<dt><div class="list-inner"><a href="./viewforum.php?f=3">AionScript</a></div></dt>
						<dd class="topics">Statistics</dd>
						<dd class="lastpost"><span>Last post</span></dd>
					</dl>
									</li>
			</ul>
			<ul class="topiclist forums">
		
	
	
	
			
					<li class="row">
						<dl title="No unread posts">
				<dt class="row-item forum_read"></dt>
				<dd>
										<div class="list-inner">
																		<a href="./viewforum.php?f=2" class="forumtitle">Announcements</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>6</strong>
													</div>
											</div>
				</dd>
									<dd class="topics">
						Topics: <strong>6</strong><br />
						Posts: <strong>25</strong>
					</dd>
					<dd class="lastpost">
						<span>
																						<dfn>Last post</dfn>
																										<a href="./viewtopic.php?f=2&amp;p=1415#p1415" title="Re: Opportunity to VIP!" class="lastsubject">Re: Opportunity to VIP!</a> <br />
																	by <a href="./memberlist.php?mode=viewprofile&amp;u=353" class="username">Diavolakos</a>
																	<a href="./viewtopic.php?f=2&amp;p=1415#p1415" title="View the latest post">
										<i class="icon fa-external-link-square fa-fw icon-lightgray icon-md" aria-hidden="true"></i><span class="sr-only">View the latest post</span>
									</a>
																<br />Sat Sep 02, 2017 9:54 am
													</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl title="No unread posts">
				<dt class="row-item forum_read"></dt>
				<dd>
										<div class="list-inner">
																		<a href="./viewforum.php?f=6" class="forumtitle">General Discussion</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>197</strong>
													</div>
											</div>
				</dd>
									<dd class="topics">
						Topics: <strong>197</strong><br />
						Posts: <strong>1013</strong>
					</dd>
					<dd class="lastpost">
						<span>
																						<dfn>Last post</dfn>
																										<a href="./viewtopic.php?f=6&amp;p=2319#p2319" title="Re: Aion 4.6 Nostalgia" class="lastsubject">Re: Aion 4.6 Nostalgia</a> <br />
																	by <a href="./memberlist.php?mode=viewprofile&amp;u=48" style="color: #00AA00;" class="username-coloured">agonic</a>
																	<a href="./viewtopic.php?f=6&amp;p=2319#p2319" title="View the latest post">
										<i class="icon fa-external-link-square fa-fw icon-lightgray icon-md" aria-hidden="true"></i><span class="sr-only">View the latest post</span>
									</a>
																<br />Fri May 04, 2018 11:03 am
													</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl title="No unread posts">
				<dt class="row-item forum_read"></dt>
				<dd>
										<div class="list-inner">
																		<a href="./viewforum.php?f=7" class="forumtitle">Tutorials</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>26</strong>
													</div>
											</div>
				</dd>
									<dd class="topics">
						Topics: <strong>26</strong><br />
						Posts: <strong>148</strong>
					</dd>
					<dd class="lastpost">
						<span>
																						<dfn>Last post</dfn>
																										<a href="./viewtopic.php?f=7&amp;p=2274#p2274" title="Exclude Monsters from attack" class="lastsubject">Exclude Monsters from attack</a> <br />
																	by <a href="./memberlist.php?mode=viewprofile&amp;u=63" class="username">ugel</a>
																	<a href="./viewtopic.php?f=7&amp;p=2274#p2274" title="View the latest post">
										<i class="icon fa-external-link-square fa-fw icon-lightgray icon-md" aria-hidden="true"></i><span class="sr-only">View the latest post</span>
									</a>
																<br />Wed Mar 21, 2018 5:49 pm
													</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl title="No unread posts">
				<dt class="row-item forum_read"></dt>
				<dd>
										<div class="list-inner">
																		<a href="./viewforum.php?f=4" class="forumtitle">Downloads</a>
																		
												<div class="responsive-show" style="display: none;">
															Topics: <strong>54</strong>
													</div>
											</div>
				</dd>
									<dd class="topics">
						Topics: <strong>54</strong><br />
						Posts: <strong>478</strong>
					</dd>
					<dd class="lastpost">
						<span>
																						<dfn>Last post</dfn>
																										<a href="./viewtopic.php?f=4&amp;p=2303#p2303" title="Re: Little update for you guys NA/EU" class="lastsubject">Re: Little update for you guy…</a> <br />
																	by <a href="./memberlist.php?mode=viewprofile&amp;u=333" class="username">letmehaxyo</a>
																	<a href="./viewtopic.php?f=4&amp;p=2303#p2303" title="View the latest post">
										<i class="icon fa-external-link-square fa-fw icon-lightgray icon-md" aria-hidden="true"></i><span class="sr-only">View the latest post</span>
									</a>
																<br />Sat Apr 14, 2018 2:53 am
													</span>
					</dd>
							</dl>
					</li>
			
	
	
			
					<li class="row">
						<dl title="No unread posts">
				<dt class="row-item forum_read_subforum"></dt>
				<dd>
										<div class="list-inner">
																		<a href="./viewforum.php?f=8" class="forumtitle">LUA Scripting</a>
																																<br /><strong>Subforums:</strong>
															<a href="./viewforum.php?f=9" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Assassin
								</a>
								, 															<a href="./viewforum.php?f=10" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Bard
								</a>
								, 															<a href="./viewforum.php?f=11" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Gladiator
								</a>
								, 															<a href="./viewforum.php?f=12" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Templar
								</a>
								, 															<a href="./viewforum.php?f=13" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Ranger
								</a>
								, 															<a href="./viewforum.php?f=14" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Spiritmaster
								</a>
								, 															<a href="./viewforum.php?f=15" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Sorcerer
								</a>
								, 															<a href="./viewforum.php?f=16" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Cleric
								</a>
								, 															<a href="./viewforum.php?f=17" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Chanter
								</a>
								, 															<a href="./viewforum.php?f=18" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Gunner
								</a>
								, 															<a href="./viewforum.php?f=19" class="subforum read" title="No unread posts">
									<i class="icon fa-file-o fa-fw  icon-blue icon-md" aria-hidden="true"></i>Aethertech
								</a>
																												
												<div class="responsive-show" style="display: none;">
															Topics: <strong>49</strong>
													</div>
											</div>
				</dd>
									<dd class="topics">
						Topics: <strong>49</strong><br />
						Posts: <strong>519</strong>
					</dd>
					<dd class="lastpost">
						<span>
																						<dfn>Last post</dfn>
																										<a href="./viewtopic.php?f=8&amp;p=2295#p2295" title="Botting EU" class="lastsubject">Botting EU</a> <br />
																	by <a href="./memberlist.php?mode=viewprofile&amp;u=468" class="username">LordSnack</a>
																	<a href="./viewtopic.php?f=8&amp;p=2295#p2295" title="View the latest post">
										<i class="icon fa-external-link-square fa-fw icon-lightgray icon-md" aria-hidden="true"></i><span class="sr-only">View the latest post</span>
									</a>
																<br />Sun Apr 01, 2018 4:02 pm
													</span>
					</dd>
							</dl>
					</li>
			
				</ul>

			</div>
		</div>
		


	<form method="post" action="./ucp.php?mode=login" class="headerspace">
	<h3><a href="./ucp.php?mode=login">Login</a>&nbsp; &bull; &nbsp;<a href="./ucp.php?mode=register">Register</a></h3>
		<fieldset class="quick-login">
			<label for="username"><span>Username:</span> <input type="text" tabindex="1" name="username" id="username" size="10" class="inputbox" title="Username" /></label>
			<label for="password"><span>Password:</span> <input type="password" tabindex="2" name="password" id="password" size="10" class="inputbox" title="Password" autocomplete="off" /></label>
							<a href="./ucp.php?mode=sendpassword">I forgot my password</a>
										<span class="responsive-hide">|</span> <label for="autologin">Remember me <input type="checkbox" tabindex="4" name="autologin" id="autologin" /></label>
						<input type="submit" tabindex="5" name="login" value="Login" class="button2" />
			<input type="hidden" name="redirect" value="./index.php?" />

		</fieldset>
	</form>


	<div class="stat-block online-list">
		<h3>Who is online</h3>		<p>
						In total there are <strong>2</strong> users online :: 1 registered, 0 hidden and 1 guest (based on users active over the past 5 minutes)<br />Most users ever online was <strong>12</strong> on Sun Dec 10, 2017 11:12 am<br /> 
								</p>
	</div>



	<div class="stat-block statistics">
		<h3>Statistics</h3>
		<p>
						Total posts <strong>2262</strong> &bull; Total topics <strong>340</strong> &bull; Total members <strong>537</strong> &bull; Our newest member <strong><a href="./memberlist.php?mode=viewprofile&amp;u=706" class="username">dimeco</a></strong>
					</p>
	</div>


				
			</div>

	<div class="inventea-footer-wrapper">
		<div id="page-footer" class="inventea-footer" role="contentinfo">
			<nav role="navigation">
	<ul id="nav-footer" class="nav-footer linklist" role="menubar">
		<li class="breadcrumbs">
									<span class="crumb"><a href="./index.php" data-navbar-reference="index"><span>Board index</span></a></span>					</li>

						<li class="small-icon" data-last-responsive="true"><a href="./memberlist.php?mode=contactadmin" role="menuitem">Contact us</a></li>
				
		<li class="small-icon"><a href="./ucp.php?mode=delete_cookies" data-ajax="true" data-refresh="true" role="menuitem">Delete all board cookies</a></li>
				<li>All times are <span title="UTC">UTC</span></li>
			</ul>
</nav>

			<footer class="inventea-credits">
								Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Limited<br />
								Style we_universal created by <a href="https://inventea.com/" title="phpBB styles, HTML5 &amp; CSS3 templates">INVENTEA</a> & <a href="http://xeronix.org/" title="phpBB styles and much more">nextgen</a>
											</footer>
		</div>
	</div>

	<div id="darkenwrapper" class="darkenwrapper" data-ajax-error-title="AJAX error" data-ajax-error-text="Something went wrong when processing your request." data-ajax-error-text-abort="User aborted request." data-ajax-error-text-timeout="Your request timed out; please try again." data-ajax-error-text-parsererror="Something went wrong with the request and the server returned an invalid reply.">
		<div id="darken" class="darken">&nbsp;</div>
	</div>

	<div id="phpbb_alert" class="phpbb_alert" data-l-err="Error" data-l-timeout-processing-req="Request timed out.">
		<a href="#" class="alert_close">
			<i class="icon fa-times-circle fa-fw" aria-hidden="true"></i>
		</a>
	<h3 class="alert_title">&nbsp;</h3><p class="alert_text"></p>
	</div>
	<div id="phpbb_confirm" class="phpbb_alert">
		<a href="#" class="alert_close">
			<i class="icon fa-times-circle fa-fw" aria-hidden="true"></i>
		</a>
		<div class="alert_text"></div>
	</div>

<div>
	<a id="bottom" class="anchor" accesskey="z"></a>
	</div>
</div>

<script type="text/javascript" src="./assets/javascript/jquery.min.js?assets_version=25"></script>
<script type="text/javascript" src="./assets/javascript/core.js?assets_version=25"></script>



<script type="text/javascript" src="./styles/prosilver/template/forum_fn.js?assets_version=25"></script>
<script type="text/javascript" src="./styles/prosilver/template/ajax.js?assets_version=25"></script>



</body>
</html>
